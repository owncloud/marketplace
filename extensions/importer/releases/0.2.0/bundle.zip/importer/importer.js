define(["vue3-gettext","./js/chunks/index-D_mCHjA_.mjs","@ownclouders/web-pkg","pinia","vue"],function(n,e,t,i,u){"use strict";return e.index});
