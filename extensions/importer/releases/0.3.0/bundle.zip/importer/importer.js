define(["vue3-gettext","./js/chunks/index-oubXuYF8.mjs","@ownclouders/web-pkg","pinia","vue"],function(n,e,t,i,u){"use strict";return e.index});
