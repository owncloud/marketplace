define(["vue3-gettext","./js/chunks/index-CuIuSpnX.mjs","@ownclouders/web-pkg","pinia","vue"],(function(n,e,t,i,u){"use strict";return e.index}));
