define(["require","vue3-gettext","./js/chunks/index-CO-BIb4w.mjs","@ownclouders/web-pkg","pinia","vue"],(function(i,u,e,n,t,r){"use strict";return e.index}));
