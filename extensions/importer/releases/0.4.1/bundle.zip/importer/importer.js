define(["require","vue3-gettext","./js/chunks/index-HAr86cte.mjs","@ownclouders/web-pkg","pinia","vue"],(function(i,u,e,n,t,r){"use strict";return e.index}));
